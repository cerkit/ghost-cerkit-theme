﻿var sidebar = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1;

  return "<!-- sidebar -->\r\n"
    + ((stack1 = this.invokePartial(partials['search-form'],depth0,{"name":"search-form","data":data,"helpers":helpers,"partials":partials})) != null ? stack1 : "")
    + "<div id=\"sidebar-component-container\"></div>\r\n"
    + ((stack1 = this.invokePartial(partials['bio-panel'],depth0,{"name":"bio-panel","data":data,"helpers":helpers,"partials":partials})) != null ? stack1 : "")
    + ((stack1 = this.invokePartial(partials['sidebar-theme-picker'],depth0,{"name":"sidebar-theme-picker","data":data,"helpers":helpers,"partials":partials})) != null ? stack1 : "")
    + "<!-- /sidebar -->";
},"usePartial":true,"useData":true});