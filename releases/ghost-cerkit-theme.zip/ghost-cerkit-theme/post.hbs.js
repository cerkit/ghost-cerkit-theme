﻿var post = Handlebars.template({"1":function(depth0,helpers,partials,data) {
    var stack1, helper, options, alias1=helpers.helperMissing, alias2="function", alias3=helpers.blockHelperMissing, alias4=this.escapeExpression, buffer = 
  "<header class=\"main-header post-head "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.image : depth0),{"name":"if","hash":{},"fn":this.program(2, data, 0),"inverse":this.program(4, data, 0),"data":data})) != null ? stack1 : "")
    + "\"></header>\r\n<main class=\"content\" role=\"main\">\r\n	<div class=\"row\">\r\n		<div id=\"sidebar-container\" class=\"col-md-4\">\r\n";
  stack1 = ((helper = (helper = helpers.author || (depth0 != null ? depth0.author : depth0)) != null ? helper : alias1),(options={"name":"author","hash":{},"fn":this.program(6, data, 0),"inverse":this.noop,"data":data}),(typeof helper === alias2 ? helper.call(depth0,options) : helper));
  if (!helpers.author) { stack1 = alias3.call(depth0,stack1,options)}
  if (stack1 != null) { buffer += stack1; }
  buffer += "		</div> <!-- .col-md-4 -->\r\n		<div class=\"col-md-8\">\r\n			<article class=\""
    + alias4(((helper = (helper = helpers.post_class || (depth0 != null ? depth0.post_class : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"post_class","hash":{},"data":data}) : helper)))
    + "\">\r\n				<div class=\"panel panel-primary\">\r\n					<div class=\"panel-heading\">\r\n						<h1 class=\"panel-title\">"
    + alias4(((helper = (helper = helpers.title || (depth0 != null ? depth0.title : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"title","hash":{},"data":data}) : helper)))
    + "</h1>\r\n						<section class=\"post-meta\">\r\n							<i class=\"fa fa-fw fa-lg fa-calendar\"></i> <time class=\"post-date\" datetime=\""
    + alias4((helpers.date || (depth0 && depth0.date) || alias1).call(depth0,{"name":"date","hash":{"format":"YYYY-MM-DD"},"data":data}))
    + "\">"
    + alias4((helpers.date || (depth0 && depth0.date) || alias1).call(depth0,{"name":"date","hash":{"format":"DD MMMM YYYY"},"data":data}))
    + "</time>\r\n"
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.tags : depth0),{"name":"if","hash":{},"fn":this.program(8, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "")
    + "						</section>\r\n					</div>\r\n					<div class=\"panel-body\">\r\n						<section class=\"post-content\">\r\n							"
    + alias4(((helper = (helper = helpers.content || (depth0 != null ? depth0.content : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"content","hash":{},"data":data}) : helper)))
    + "\r\n						</section>\r\n					</div>\r\n				</div>\r\n			</article>\r\n		</div> <!-- .col-md-8 -->\r\n	</div> <!-- .row -->\r\n	<div class=\"row\">\r\n		<div class=\"col-md-6 col-md-offset-3\">\r\n			<div class=\"panel panel-default\">\r\n				<div class=\"panel-body\">\r\n					<div id=\"disqus_thread\"></div>\r\n					<script>\r\n						var disqus_config = function () {\r\n							this.page.url = \""
    + alias4(((helper = (helper = helpers.url || (depth0 != null ? depth0.url : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"url","hash":{},"data":data}) : helper)))
    + "\";\r\n							this.page.identifier = '"
    + alias4(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "';\r\n						};\r\n\r\n						(function () { // DON'T EDIT BELOW THIS LINE\r\n							var d = document, s = d.createElement('script');\r\n\r\n							s.src = 'https://' + disqusSite + disqusSource;\r\n\r\n							s.setAttribute('data-timestamp', +new Date());\r\n							(d.head || d.body).appendChild(s);\r\n						})();\r\n					</script>\r\n					<noscript>Please enable JavaScript to view the <a href=\"https://disqus.com/?ref_noscript\" rel=\"nofollow\">comments powered by Disqus.</a></noscript>\r\n				</div> <!-- .panel-body (comments) -->\r\n			</div> <!-- comment panel -->\r\n		</div> <!-- .col-md-6 -->\r\n	</div> <!-- .row -->\r\n</main>\r\n<aside class=\"read-next\">\r\n";
  stack1 = ((helper = (helper = helpers.next_post || (depth0 != null ? depth0.next_post : depth0)) != null ? helper : alias1),(options={"name":"next_post","hash":{},"fn":this.program(11, data, 0),"inverse":this.noop,"data":data}),(typeof helper === alias2 ? helper.call(depth0,options) : helper));
  if (!helpers.next_post) { stack1 = alias3.call(depth0,stack1,options)}
  if (stack1 != null) { buffer += stack1; }
  stack1 = ((helper = (helper = helpers.prev_post || (depth0 != null ? depth0.prev_post : depth0)) != null ? helper : alias1),(options={"name":"prev_post","hash":{},"fn":this.program(13, data, 0),"inverse":this.noop,"data":data}),(typeof helper === alias2 ? helper.call(depth0,options) : helper));
  if (!helpers.prev_post) { stack1 = alias3.call(depth0,stack1,options)}
  if (stack1 != null) { buffer += stack1; }
  return buffer + "</aside>\r\n<div class=\"hidden\">\r\n	<!-- we're going to move this to the sidebar... -->\r\n	<div class=\"panel panel-primary share sidebar-component\">\r\n		<div class=\"panel-heading\">\r\n			<h4 class=\"panel-title\">Share this post</h4>\r\n		</div> <!-- .panel-heading (share) -->\r\n		<div class=\"panel-body\">\r\n			<a class=\"text-primary share-link\" href=\"https://twitter.com/intent/tweet?text="
    + alias4((helpers.encode || (depth0 && depth0.encode) || alias1).call(depth0,(depth0 != null ? depth0.title : depth0),{"name":"encode","hash":{},"data":data}))
    + "&amp;url="
    + alias4((helpers.url || (depth0 && depth0.url) || alias1).call(depth0,{"name":"url","hash":{"absolute":"true"},"data":data}))
    + "\"\r\n			   onclick=\"window.open(this.href, 'twitter-share', 'width=550,height=235');return false;\"\r\n			   title=\"Share on Twitter\" aria-label=\"Share on Twitter\"><i class=\"fa fa-3x fa-twitter-square\"></i><span class=\"sr-only\">Twitter</span></a>\r\n			<a class=\"text-primary share-link\" href=\"https://www.facebook.com/sharer/sharer.php?u="
    + alias4((helpers.url || (depth0 && depth0.url) || alias1).call(depth0,{"name":"url","hash":{"absolute":"true"},"data":data}))
    + "\"\r\n			   onclick=\"window.open(this.href, 'facebook-share','width=580,height=296');return false;\"\r\n			   title=\"Share on Facebook\" aria-label=\"Share on Facebook\"><i class=\"fa fa-3x fa-facebook-square\"></i><span class=\"sr-only\">Facebook</span></a>\r\n			<a class=\"text-primary share-link\" href=\"https://plus.google.com/share?url="
    + alias4((helpers.url || (depth0 && depth0.url) || alias1).call(depth0,{"name":"url","hash":{"absolute":"true"},"data":data}))
    + "\"\r\n			   onclick=\"window.open(this.href, 'google-plus-share', 'width=490,height=530');return false;\"\r\n			   title=\"Share on Google+\" aria-label=\"Share on Google+\"><i class=\"fa fa-3x fa-google-plus-square\"></i><span class=\"sr-only\">Google+</span></a>\r\n		</div> <!-- .panel-body (share) -->\r\n	</div> <!-- .panel (share) -->\r\n</div>\r\n";
},"2":function(depth0,helpers,partials,data) {
    var helper;

  return "\" style=\"background-image: url("
    + this.escapeExpression(((helper = (helper = helpers.image || (depth0 != null ? depth0.image : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"image","hash":{},"data":data}) : helper)))
    + ")";
},"4":function(depth0,helpers,partials,data) {
    return "no-cover";
},"6":function(depth0,helpers,partials,data) {
    var stack1;

  return ((stack1 = this.invokePartial(partials.sidebar,depth0,{"name":"sidebar","data":data,"indent":"\t\t\t","helpers":helpers,"partials":partials})) != null ? stack1 : "");
},"8":function(depth0,helpers,partials,data) {
    var stack1;

  return ((stack1 = (helpers.foreach || (depth0 && depth0.foreach) || helpers.helperMissing).call(depth0,(depth0 != null ? depth0.tags : depth0),{"name":"foreach","hash":{},"fn":this.program(9, data, 0),"inverse":this.noop,"data":data})) != null ? stack1 : "");
},"9":function(depth0,helpers,partials,data) {
    var helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "								<a href=\""
    + alias3(((helper = (helper = helpers.url || (depth0 != null ? depth0.url : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"url","hash":{},"data":data}) : helper)))
    + "\" title=\""
    + alias3(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"name","hash":{},"data":data}) : helper)))
    + "\" class=\"tag-button tag-"
    + alias3(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + " btn btn-sm btn-default\"><i class=\"fa fa-fw fa-tag\"></i>&nbsp;"
    + alias3(((helper = (helper = helpers.name || (depth0 != null ? depth0.name : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"name","hash":{},"data":data}) : helper)))
    + "</a>\r\n";
},"11":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "	<a class=\"read-next-story "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.image : depth0),{"name":"if","hash":{},"fn":this.program(2, data, 0),"inverse":this.program(4, data, 0),"data":data})) != null ? stack1 : "")
    + "\" href=\""
    + alias3(((helper = (helper = helpers.url || (depth0 != null ? depth0.url : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"url","hash":{},"data":data}) : helper)))
    + "\">\r\n		<section class=\"nextprev-post\">\r\n			<h2>"
    + alias3(((helper = (helper = helpers.title || (depth0 != null ? depth0.title : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"title","hash":{},"data":data}) : helper)))
    + "</h2>\r\n			<p>"
    + alias3((helpers.excerpt || (depth0 && depth0.excerpt) || alias1).call(depth0,{"name":"excerpt","hash":{"words":"19"},"data":data}))
    + "&hellip;</p>\r\n		</section>\r\n	</a>\r\n";
},"13":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "	<a class=\"read-next-story prev "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.image : depth0),{"name":"if","hash":{},"fn":this.program(2, data, 0),"inverse":this.program(4, data, 0),"data":data})) != null ? stack1 : "")
    + "\" href=\""
    + alias3(((helper = (helper = helpers.url || (depth0 != null ? depth0.url : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"url","hash":{},"data":data}) : helper)))
    + "\">\r\n		<section class=\"nextprev-post\">\r\n			<h2>"
    + alias3(((helper = (helper = helpers.title || (depth0 != null ? depth0.title : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"title","hash":{},"data":data}) : helper)))
    + "</h2>\r\n			<p>"
    + alias3((helpers.excerpt || (depth0 && depth0.excerpt) || alias1).call(depth0,{"name":"excerpt","hash":{"words":"19"},"data":data}))
    + "&hellip;</p>\r\n		</section>\r\n	</a>\r\n";
},"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1, helper, options, buffer = "";

  stack1 = ((helper = (helper = helpers.post || (depth0 != null ? depth0.post : depth0)) != null ? helper : helpers.helperMissing),(options={"name":"post","hash":{},"fn":this.program(1, data, 0),"inverse":this.noop,"data":data}),(typeof helper === "function" ? helper.call(depth0,options) : helper));
  if (!helpers.post) { stack1 = helpers.blockHelperMissing.call(depth0,stack1,options)}
  if (stack1 != null) { buffer += stack1; }
  return buffer;
},"usePartial":true,"useData":true});