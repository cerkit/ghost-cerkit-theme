﻿var post = Handlebars.template({"1":function(depth0,helpers,partials,data) {
    var stack1, helper, options, alias1=helpers.helperMissing, alias2="function", alias3=helpers.blockHelperMissing, alias4=this.escapeExpression, buffer = 
  "\n<header class=\"main-header post-head "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.image : depth0),{"name":"if","hash":{},"fn":this.program(2, data, 0),"inverse":this.program(4, data, 0),"data":data})) != null ? stack1 : "")
    + "\">\n</header>\n<main class=\"content\" role=\"main\">\n	<div class=\"row\">\n		<div id=\"sidebar-container\" class=\"col-md-4\">\n";
  stack1 = ((helper = (helper = helpers.author || (depth0 != null ? depth0.author : depth0)) != null ? helper : alias1),(options={"name":"author","hash":{},"fn":this.program(6, data, 0),"inverse":this.noop,"data":data}),(typeof helper === alias2 ? helper.call(depth0,options) : helper));
  if (!helpers.author) { stack1 = alias3.call(depth0,stack1,options)}
  if (stack1 != null) { buffer += stack1; }
  buffer += "		</div> <!-- .col-md-4 -->\n		<div class=\"col-md-8\">\n			<article class=\""
    + alias4(((helper = (helper = helpers.post_class || (depth0 != null ? depth0.post_class : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"post_class","hash":{},"data":data}) : helper)))
    + "\">				\n                <div class=\"panel panel-default\">\n                    <div class=\"panel-heading\">\n                        <h1 class=\"panel-title\">"
    + alias4(((helper = (helper = helpers.title || (depth0 != null ? depth0.title : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"title","hash":{},"data":data}) : helper)))
    + "</h1>\n                        <section class=\"post-meta\">\n                            <i class=\"fa fa-fw fa-lg fa-calendar\"></i> <time class=\"post-date\" datetime=\""
    + alias4((helpers.date || (depth0 && depth0.date) || alias1).call(depth0,{"name":"date","hash":{"format":"YYYY-MM-DD"},"data":data}))
    + "\">"
    + alias4((helpers.date || (depth0 && depth0.date) || alias1).call(depth0,{"name":"date","hash":{"format":"DD MMMM YYYY"},"data":data}))
    + "</time> "
    + alias4((helpers.tags || (depth0 && depth0.tags) || alias1).call(depth0,{"name":"tags","hash":{"prefix":" on "},"data":data}))
    + "\n                        </section>\n                    </div>\n                    <div class=\"panel-body\">\n                        <section class=\"post-content\">\n                            "
    + alias4(((helper = (helper = helpers.content || (depth0 != null ? depth0.content : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"content","hash":{},"data":data}) : helper)))
    + "\n                        </section>\n                    </div>\n                </div>\n			</article>\n		</div> <!-- .col-md-8 -->\n	</div> <!-- .row -->\n	<div class=\"row\">\n		<div class=\"col-md-6 col-md-offset-3\">\n			<div class=\"panel panel-default\">\n				<div class=\"panel-body\">\n					<div id=\"disqus_thread\"></div>\n					<script>						\n						var disqus_config = function () {\n						this.page.url = \""
    + alias4(((helper = (helper = helpers.url || (depth0 != null ? depth0.url : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"url","hash":{},"data":data}) : helper)))
    + "\"; \n						this.page.identifier = '"
    + alias4(((helper = (helper = helpers.id || (depth0 != null ? depth0.id : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"id","hash":{},"data":data}) : helper)))
    + "';\n						};\n						\n						(function() { // DON'T EDIT BELOW THIS LINE\n						var d = document, s = d.createElement('script');\n\n						s.src = 'https://' + disqusSite + disqusSource;\n\n						s.setAttribute('data-timestamp', +new Date());\n						(d.head || d.body).appendChild(s);\n						})();\n					</script>\n					<noscript>Please enable JavaScript to view the <a href=\"https://disqus.com/?ref_noscript\" rel=\"nofollow\">comments powered by Disqus.</a></noscript>\n				</div> <!-- .panel-body (comments) -->\n			</div> <!-- comment panel -->\n		</div> <!-- .col-md-6 -->\n	</div> <!-- .row -->\n</main>\n<aside class=\"read-next\">\n";
  stack1 = ((helper = (helper = helpers.next_post || (depth0 != null ? depth0.next_post : depth0)) != null ? helper : alias1),(options={"name":"next_post","hash":{},"fn":this.program(8, data, 0),"inverse":this.noop,"data":data}),(typeof helper === alias2 ? helper.call(depth0,options) : helper));
  if (!helpers.next_post) { stack1 = alias3.call(depth0,stack1,options)}
  if (stack1 != null) { buffer += stack1; }
  stack1 = ((helper = (helper = helpers.prev_post || (depth0 != null ? depth0.prev_post : depth0)) != null ? helper : alias1),(options={"name":"prev_post","hash":{},"fn":this.program(10, data, 0),"inverse":this.noop,"data":data}),(typeof helper === alias2 ? helper.call(depth0,options) : helper));
  if (!helpers.prev_post) { stack1 = alias3.call(depth0,stack1,options)}
  if (stack1 != null) { buffer += stack1; }
  return buffer + "</aside>\n<div class=\"hidden\">\n    <!-- we're going to move this to the sidebar... -->\n    <div class=\"panel panel-primary share move-to-sidebar\">\n        <div class=\"panel-heading\">\n            <h4 class=\"panel-title\">Share this post</h4>\n        </div> <!-- .panel-heading (share) -->\n        <div class=\"panel-body\">\n            <a class=\"btn btn-default\" href=\"https://twitter.com/intent/tweet?text="
    + alias4((helpers.encode || (depth0 && depth0.encode) || alias1).call(depth0,(depth0 != null ? depth0.title : depth0),{"name":"encode","hash":{},"data":data}))
    + "&amp;url="
    + alias4((helpers.url || (depth0 && depth0.url) || alias1).call(depth0,{"name":"url","hash":{"absolute":"true"},"data":data}))
    + "\"\n               onclick=\"window.open(this.href, 'twitter-share', 'width=550,height=235');return false;\"\n               title=\"Share on Twitter\" aria-label=\"Share on Twitter\">\n                <i class=\"fa fa-lg fa-twitter-square\"></i><span class=\"hidden\">Twitter</span>\n            </a>\n            <a class=\"btn btn-default\" href=\"https://www.facebook.com/sharer/sharer.php?u="
    + alias4((helpers.url || (depth0 && depth0.url) || alias1).call(depth0,{"name":"url","hash":{"absolute":"true"},"data":data}))
    + "\"\n               onclick=\"window.open(this.href, 'facebook-share','width=580,height=296');return false;\"\n               title=\"Share on Facebook\" aria-label=\"Share on Facebook\">\n                <i class=\"fa fa-lg fa-facebook-official\"></i><span class=\"hidden\">Facebook</span>\n            </a>\n            <a class=\"btn btn-default\" href=\"https://plus.google.com/share?url="
    + alias4((helpers.url || (depth0 && depth0.url) || alias1).call(depth0,{"name":"url","hash":{"absolute":"true"},"data":data}))
    + "\"\n               onclick=\"window.open(this.href, 'google-plus-share', 'width=490,height=530');return false;\"\n               title=\"Share on Google+\" aria-label=\"Share on Google+\">\n                <i class=\"fa fa-lg fa-google-plus-square\"></i><span class=\"hidden\">Google+</span>\n            </a>\n        </div> <!-- .panel-body (share) -->\n    </div> <!-- .panel (share) -->\n</div>\n";
},"2":function(depth0,helpers,partials,data) {
    var helper;

  return "\" style=\"background-image: url("
    + this.escapeExpression(((helper = (helper = helpers.image || (depth0 != null ? depth0.image : depth0)) != null ? helper : helpers.helperMissing),(typeof helper === "function" ? helper.call(depth0,{"name":"image","hash":{},"data":data}) : helper)))
    + ")";
},"4":function(depth0,helpers,partials,data) {
    return "no-cover";
},"6":function(depth0,helpers,partials,data) {
    var stack1;

  return ((stack1 = this.invokePartial(partials.sidebar,depth0,{"name":"sidebar","data":data,"indent":"\t\t\t    ","helpers":helpers,"partials":partials})) != null ? stack1 : "");
},"8":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "    <a class=\"read-next-story "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.image : depth0),{"name":"if","hash":{},"fn":this.program(2, data, 0),"inverse":this.program(4, data, 0),"data":data})) != null ? stack1 : "")
    + "\" href=\""
    + alias3(((helper = (helper = helpers.url || (depth0 != null ? depth0.url : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"url","hash":{},"data":data}) : helper)))
    + "\">\n        <section class=\"nextprev-post\">\n            <h2>"
    + alias3(((helper = (helper = helpers.title || (depth0 != null ? depth0.title : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"title","hash":{},"data":data}) : helper)))
    + "</h2>\n            <p>"
    + alias3((helpers.excerpt || (depth0 && depth0.excerpt) || alias1).call(depth0,{"name":"excerpt","hash":{"words":"19"},"data":data}))
    + "&hellip;</p>\n        </section>\n    </a>\n";
},"10":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "    <a class=\"read-next-story prev "
    + ((stack1 = helpers['if'].call(depth0,(depth0 != null ? depth0.image : depth0),{"name":"if","hash":{},"fn":this.program(2, data, 0),"inverse":this.program(4, data, 0),"data":data})) != null ? stack1 : "")
    + "\" href=\""
    + alias3(((helper = (helper = helpers.url || (depth0 != null ? depth0.url : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"url","hash":{},"data":data}) : helper)))
    + "\">\n        <section class=\"nextprev-post\">\n            <h2>"
    + alias3(((helper = (helper = helpers.title || (depth0 != null ? depth0.title : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"title","hash":{},"data":data}) : helper)))
    + "</h2>\n            <p>"
    + alias3((helpers.excerpt || (depth0 && depth0.excerpt) || alias1).call(depth0,{"name":"excerpt","hash":{"words":"19"},"data":data}))
    + "&hellip;</p>\n        </section>\n    </a>\n";
},"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1, helper, options, buffer = 
  "\n\n";
  stack1 = ((helper = (helper = helpers.post || (depth0 != null ? depth0.post : depth0)) != null ? helper : helpers.helperMissing),(options={"name":"post","hash":{},"fn":this.program(1, data, 0),"inverse":this.noop,"data":data}),(typeof helper === "function" ? helper.call(depth0,options) : helper));
  if (!helpers.post) { stack1 = helpers.blockHelperMissing.call(depth0,stack1,options)}
  if (stack1 != null) { buffer += stack1; }
  return buffer;
},"usePartial":true,"useData":true});