﻿var default = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    var stack1, helper, alias1=helpers.helperMissing, alias2="function", alias3=this.escapeExpression;

  return "﻿<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n    <meta charset=\"utf-8\" />\n    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />\n    <title>"
    + alias3(((helper = (helper = helpers.meta_title || (depth0 != null ? depth0.meta_title : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"meta_title","hash":{},"data":data}) : helper)))
    + "</title>\n    <meta name=\"description\" content=\""
    + alias3(((helper = (helper = helpers.meta_description || (depth0 != null ? depth0.meta_description : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"meta_description","hash":{},"data":data}) : helper)))
    + "\" />\n\n    <meta name=\"HandheldFriendly\" content=\"True\" />\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n\n    <link rel=\"shortcut icon\" href=\""
    + alias3((helpers.asset || (depth0 && depth0.asset) || alias1).call(depth0,"favicon.ico",{"name":"asset","hash":{},"data":data}))
    + "\">\n	\n    "
    + alias3(((helper = (helper = helpers.ghost_head || (depth0 != null ? depth0.ghost_head : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"ghost_head","hash":{},"data":data}) : helper)))
    + "\n</head>\n<body class=\""
    + alias3(((helper = (helper = helpers.body_class || (depth0 != null ? depth0.body_class : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"body_class","hash":{},"data":data}) : helper)))
    + "\">\n	"
    + alias3(((helper = (helper = helpers.navigation || (depth0 != null ? depth0.navigation : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"navigation","hash":{},"data":data}) : helper)))
    + "\n	<div class=\"site-wrapper container-fluid\">\n		"
    + ((stack1 = ((helper = (helper = helpers.body || (depth0 != null ? depth0.body : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"body","hash":{},"data":data}) : helper))) != null ? stack1 : "")
    + "\n		\n		<div class=\"row\">\n			<div class=\"col-md-12\">\n				<footer>\n					<div class=\"container text-center\">"
    + ((stack1 = this.invokePartial(partials.copyright,depth0,{"name":"copyright","data":data,"helpers":helpers,"partials":partials})) != null ? stack1 : "")
    + "</div>\n				</footer>\n			</div>\n		</div>\n\n    </div>\n	\n	<!-- Bootstrap -->\n	<link id=\"bootstrap-theme\" href=\"//maxcdn.bootstrapcdn.com/bootswatch/3.3.6/simplex/bootstrap.min.css\" rel=\"stylesheet\"  crossorigin=\"anonymous\" />\n	<!-- Fontawesome -->\n	<link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css\">\n	\n    <script type=\"text/javascript\" src=\"//code.jquery.com/jquery-1.12.0.min.js\"></script>\n	<script type=\"text/javascript\" src=\"//cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js\"></script>\n	\n	<!-- theme specific css -->\n	<link rel=\"stylesheet\" type=\"text/css\" href=\""
    + alias3((helpers.asset || (depth0 && depth0.asset) || alias1).call(depth0,"css/screen.min.css",{"name":"asset","hash":{},"data":data}))
    + "\" />\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"//fonts.googleapis.com/css?family=Merriweather:300,700,700italic,300italic|Open+Sans:700,400\" />\n	\n	<!-- minified JavaScript for Bootstrap -->\n	<script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js\" integrity=\"sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS\" crossorigin=\"anonymous\"></script>\n	\n	<!-- site specific javascript (needs to load before footer so that variables can be overridden in footer code injection) -->\n	<script type=\"text/javascript\" src=\""
    + alias3((helpers.asset || (depth0 && depth0.asset) || alias1).call(depth0,"js/site-init.min.js",{"name":"asset","hash":{},"data":data}))
    + "\"></script>\n	\n    "
    + alias3(((helper = (helper = helpers.ghost_foot || (depth0 != null ? depth0.ghost_foot : depth0)) != null ? helper : alias1),(typeof helper === alias2 ? helper.call(depth0,{"name":"ghost_foot","hash":{},"data":data}) : helper)))
    + "\n	\n	<script id=\"dsq-count-scr\" src=\"//cerkit.disqus.com/count.js\" async></script>\n\n    <script type=\"text/javascript\" src=\""
    + alias3((helpers.asset || (depth0 && depth0.asset) || alias1).call(depth0,"js/jquery.fitvids.min.js",{"name":"asset","hash":{},"data":data}))
    + "\"></script>\n    <script type=\"text/javascript\" src=\""
    + alias3((helpers.asset || (depth0 && depth0.asset) || alias1).call(depth0,"js/index.js",{"name":"asset","hash":{},"data":data}))
    + "\"></script>\n	<script type=\"text/javascript\" src=\""
    + alias3((helpers.asset || (depth0 && depth0.asset) || alias1).call(depth0,"js/bootstrap-pagination.min.js",{"name":"asset","hash":{},"data":data}))
    + "\"></script>\n	<script type=\"text/javascript\" src=\""
    + alias3((helpers.asset || (depth0 && depth0.asset) || alias1).call(depth0,"js/bootstrap-theme-selector.min.js",{"name":"asset","hash":{},"data":data}))
    + "\"></script>\n	</body>\n</html>\n";
},"usePartial":true,"useData":true});